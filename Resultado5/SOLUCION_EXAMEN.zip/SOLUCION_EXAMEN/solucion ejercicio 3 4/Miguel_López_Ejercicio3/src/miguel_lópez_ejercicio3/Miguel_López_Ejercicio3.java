/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miguel_lópez_ejercicio3;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQPreparedExpression;
import javax.xml.xquery.XQResultItem;
import javax.xml.xquery.XQResultSequence;
import net.xqj.exist.ExistXQDataSource;

/**
 *
 * @author chipi
 */
public class Miguel_López_Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws XQException {
        
        //CONEXION CON EXIST
        XQDataSource server = new ExistXQDataSource();
        server.setProperty("serverName", "localhost");
        server.setProperty("port", "8080");
        server.setProperty("user", "dam2");
        server.setProperty("password", "dam2");
        
        XQConnection con = server.getConnection();
        
        //STRING PARA GUARDAR TEMPORALMENTE EL RESULTADO
        String[] res = null;
        
        //SE PREPARA LA CONSULTA
        XQPreparedExpression consulta;
        XQResultSequence resultado;
        consulta = con.prepareExpression("/tienda/compras/compra[@idcliente = '_22']/concat(unidades,';',precio,';',fecha)");
        
        //SE EJECUTA LA CONSULTA
        resultado = consulta.executeQuery();
        
        XQResultItem r_item;
        
        //RECORREMOS EL RESULTADO
        while (resultado.next()) {
            
            r_item = (XQResultItem) resultado.getItem();
            String cad = r_item.getItemAsString(null);
            res = cad.split(";");
            
            //SE MUESTRA EL RESULTADO POR CADA NODO 
            System.out.println("Unidades: " + res[0]);
            System.out.println("Precio: " + res[1]);
            System.out.println("Fecha: " + res[2]);
            System.out.println("");
            
        }
        
        
    }
    
}
