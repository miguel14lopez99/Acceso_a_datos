/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miguel_lópez_ejercicio4;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQPreparedExpression;
import javax.xml.xquery.XQResultItem;
import javax.xml.xquery.XQResultSequence;
import net.xqj.exist.ExistXQDataSource;

/**
 *
 * @author chipi
 */
public class Miguel_López_Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws XQException {
        
        //CONEXION CON EXIST
        XQDataSource server = new ExistXQDataSource();
        server.setProperty("serverName", "localhost");
        server.setProperty("port", "8080");
        server.setProperty("user", "dam2");
        server.setProperty("password", "dam2");
        
        XQConnection con = server.getConnection();
        
        double precio;
        double descuento = 0.05;
        
        //SE PREPARA LA CONSULTA
        XQPreparedExpression consulta;
        XQResultSequence resultado;
        consulta = con.prepareExpression("/tienda/compras/compra[precio > 320]/data(precio)");
        
        //SE EJECUTA LA CONSULTA
        resultado = consulta.executeQuery();
        
        XQResultItem r_item;
        
        //RECORREMOS EL RESULTADO
        while (resultado.next()) {
            
            r_item = (XQResultItem) resultado.getItem();
            String cad = r_item.getItemAsString(null);
            precio = Double.parseDouble(cad);
            
            Double total = precio - (precio*descuento);
            
            //SE ACTUALIZA EL PRECIO DE CADA NODO RECUPERADO
            XQExpression consulta2;
            consulta2 = con.createExpression();
            consulta2.executeCommand("update value /tienda/compras/compra[precio > 320]/precio" 
                    + " with " + total);
            
        }
    }
    
}
