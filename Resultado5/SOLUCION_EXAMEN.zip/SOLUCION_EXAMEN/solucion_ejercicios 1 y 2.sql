-----------------------------------------------------
--NOMBRE Y APELLIDOS: Miguel López Gutiérrez
--NOTA:
--OBSERVACIONES:
-----------------------------------------------------


-----------------------------------------------------
--EJERCICIO 1:
--NOTA:
--OBSERVACIONES:
-----------------------------------------------------

a) /tienda/articulos/articulo/marca/text()
-----------------------------------------------------
b) /tienda/compras/compra[@idcliente = '_22']
-----------------------------------------------------
c) /tienda/clientes/cliente[ciudad = 'Ibi']/(nombre|ciudad)
-----------------------------------------------------
d) sum(/tienda/compras/compra/number(precio))
-----------------------------------------------------
e) /tienda/compras/compra[contains(fecha,'2012')]
-----------------------------------------------------
f) (sum(/tienda/compras/compra/precio))div(sum(/tienda/compras/compra/unidades))
-----------------------------------------------------




-----------------------------------------------------
--EJERCICIO 2:
--NOTA:
--OBSERVACIONES:
-----------------------------------------------------

a) 
update insert
    <disponibilidad>No</disponibilidad>
into
    /tienda/articulos/articulo[@codigo = 'A002']
-----------------------------------------------------
b) 
update replace
    /tienda/compras/compra[@idcliente = '_22' and @codigo = 'A005']/precio
with
    <precio>200</precio>
-----------------------------------------------------
c) 
update value
    /tienda/compras/compra[@idcliente = '_22' and @codigo = 'A005']/precio
with
    300
-----------------------------------------------------
d) 
update delete
    /tienda/articulos/articulo[marca = 'CANON']
-----------------------------------------------------
e) 
update rename
    /tienda/compras/compra[@idcliente = '_22']/precio
as
    'cost'


-----------------------------------------------------
--EJERCICIO 3:
--NOTA:
--OBSERVACIONES:
-----------------------------------------------------
-----------------------------------------------------
--EJERCICIO 4:
--NOTA:
--OBSERVACIONES:
-----------------------------------------------------
-----------------------------------------------------
