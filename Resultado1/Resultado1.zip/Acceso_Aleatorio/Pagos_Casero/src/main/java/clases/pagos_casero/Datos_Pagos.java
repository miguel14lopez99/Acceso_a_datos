/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.pagos_casero;

/**
 *
 * @author chipi
 */
public interface Datos_Pagos {
    
    int C_INT = 4;
    int C_DOUBLE = 8;
    
    int tamanio = (2*C_INT) + (4*C_DOUBLE); // 40    
}
